# UploadSessionCommandLogsLocations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**session_command_id** | **str** |  | 
**locations** | [**dict(str, S3DownloadLocation)**](S3DownloadLocation.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


