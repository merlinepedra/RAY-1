# SessionStateData

A way to support unions that gets around the code generator's lack of support for real unions.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startup** | [**SessionStartingUpData**](SessionStartingUpData.md) |  | [optional] 
**stopping** | [**SessionStoppingData**](SessionStoppingData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


