# File to store links to common places so they can be updated in one place


DOCS_CLUSTER = "https://docs.anyscale.com/user-guide/configure/dependency-management/anyscale-environments#cluster-environments"
